<!DOCTYPE html>
<html>
<head>

    <title>Online Shopping - Order Viewer</title>

    <style>

        body {
            font-family: Arial;
            text-align: center;
        }

        button {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
        }

        table {
            border-collapse: collapse;
            width: 80%;
            margin: 25px auto;
        }

        th, td {
            border: 1px solid black;
            padding: 10px;
        }

        th {
            background-color: lightgray;
        }

    </style>


    <script>

        function loadOrders() {

            // Create AJAX object
            var xhttp = new XMLHttpRequest();

            // Function executes when response is received
            xhttp.onreadystatechange = function() {

                if (this.readyState == 4 && this.status == 200) {

                    // Get XML response
                    var xml = this.responseXML;

                    // Get all order elements
                    var orders = xml.getElementsByTagName("order");

                    var output = "<h2>Order Details</h2>";

                    output += "<table>";

                    output += "<tr>" +
                              "<th>ID</th>" +
                              "<th>Customer</th>" +
                              "<th>Product</th>" +
                              "<th>Quantity</th>" +
                              "<th>Price</th>" +
                              "</tr>";


                    // Loop through all orders
                    for (var i = 0; i < orders.length; i++) {

                        var id =
                        orders[i].getElementsByTagName("id")[0]
                        .childNodes[0].nodeValue;

                        var customer =
                        orders[i].getElementsByTagName("customer")[0]
                        .childNodes[0].nodeValue;

                        var product =
                        orders[i].getElementsByTagName("product")[0]
                        .childNodes[0].nodeValue;

                        var quantity =
                        orders[i].getElementsByTagName("quantity")[0]
                        .childNodes[0].nodeValue;

                        var price =
                        orders[i].getElementsByTagName("price")[0]
                        .childNodes[0].nodeValue;


                        output += "<tr>";

                        output += "<td>" + id + "</td>";

                        output += "<td>" + customer + "</td>";

                        output += "<td>" + product + "</td>";

                        output += "<td>" + quantity + "</td>";

                        output += "<td>" + price + "</td>";

                        output += "</tr>";
                    }

                    output += "</table>";

                    document.getElementById("orderData").innerHTML = output;
                }
            };


            // AJAX request
            xhttp.open("GET", "orders.xml", true);

            // Send request
            xhttp.send();
        }

    </script>

</head>


<body>

    <h1>Online Shopping - Order Viewer</h1>

    <button onclick="loadOrders()">
        Load Orders
    </button>

    <div id="orderData"></div>

</body>

</html>