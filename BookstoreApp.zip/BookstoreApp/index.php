<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Mark Sheet - XML to DB Sync</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background-color: #f4f4f9;
        }
        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 90%;
            margin: 0 auto;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 5px;
            overflow: hidden;
        }
        th, td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #FF5722;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
            font-size: 13px;
        }
        tr:hover {
            background-color: #f9f9f9;
        }
        .highlight {
            font-weight: bold;
            color: #28a745;
        }
        .sync-msg {
            text-align: center;
            color: #555;
            font-style: italic;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

    <h2> Student Reports </h2>

    <?php
    // 1. Database Connection via MySQLi Object Oriented Interface
    $host = 'localhost';
    $dbUser = 'root';
    $dbPass = 'mysql'; 
    $dbName = 'school_db';

    $conn = new mysqli($host, $dbUser, $dbPass, $dbName);

    if ($conn->connect_error) {
        die("<p style='color:red; text-align:center;'>Database Connection Failed: " . $conn->connect_error . "</p>");
    }

    // 2. Read XML File and Sync to Database
    $xmlFile = 'books.xml';

    if (file_exists($xmlFile)) {
        $xml = simplexml_load_file($xmlFile);
        
        if ($xml !== false) {
            foreach ($xml->student as $student) {
                $rollno = $conn->real_escape_string($student->rollno);
                $name = $conn->real_escape_string($student->name);
                
                $m1 = (int)$student->marks->subject1;
                $m2 = (int)$student->marks->subject2;
                $m3 = (int)$student->marks->subject3;
                $m4 = (int)$student->marks->subject4;
                $m5 = (int)$student->marks->subject5;

                // Perform calculations in PHP
                $total = $m1 + $m2 + $m3 + $m4 + $m5;
                $average = $total / 5;

                // Check if the record already exists using MySQLi query logic
                $checkQuery = "SELECT rollno FROM students WHERE rollno = '$rollno'";
                $checkResult = $conn->query($checkQuery);

                if ($checkResult && $checkResult->num_rows > 0) {
                    // Update existing records with fresh XML changes
                    $updateQuery = "UPDATE students SET 
                                    name = '$name', 
                                    subject1 = $m1, subject2 = $m2, subject3 = $m3, subject4 = $m4, subject5 = $m5, 
                                    total = $total, average = $average 
                                    WHERE rollno = '$rollno'";
                    $conn->query($updateQuery);
                } else {
                    // Insert brand new student added to the XML structure
                    $insertQuery = "INSERT INTO students (rollno, name, subject1, subject2, subject3, subject4, subject5, total, average) 
                                    VALUES ('$rollno', '$name', $m1, $m2, $m3, $m4, $m5, $total, $average)";
                    $conn->query($insertQuery);
                }
            }
            
        }
    }

    // 3. Fetch Data From Database to Display
    $sql = "SELECT rollno, name, subject1, subject2, subject3, subject4, subject5, total, average FROM students";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        echo "<table>";
        echo "<tr>
                <th>Roll No</th>
                <th>Name</th>
                <th>Sub 1</th>
                <th>Sub 2</th>
                <th>Sub 3</th>
                <th>Sub 4</th>
                <th>Sub 5</th>
                <th>Total</th>
                <th>Average</th>
              </tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['rollno']) . "</td>";
            echo "<td>" . htmlspecialchars($row['name']) . "</td>";
            echo "<td>" . $row['subject1'] . "</td>";
            echo "<td>" . $row['subject2'] . "</td>";
            echo "<td>" . $row['subject3'] . "</td>";
            echo "<td>" . $row['subject4'] . "</td>";
            echo "<td>" . $row['subject5'] . "</td>";
            echo "<td><strong>" . $row['total'] . "</strong></td>";
            echo "<td class='highlight'>" . number_format($row['average'], 2) . "%</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='text-align:center;'>No records found.</p>";
    }

    $conn->close();
    ?>

</body>
</html>
